<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <title>Data Pelanggan</title>
</head>
<body>
<br>
    <div class="container" style="margin-top: 80px">
         <div class="container-fluid">
                <div class="card">
                <div class="card">
                    <div class="card-header">
                        <strong>DATA PELANGGAN</strong>
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('datapelanggans.create')); ?>" class="btn btn-md btn-success" style="margin-bottom: 25px">Tambah Data</a>
                        <table class="table table-bordered" id="myTable" >
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">NAMA PELANGGAN</th>
                                    <th scope="col">ALAMAT</th>
                                    
                                    <th scope="col">OPSI</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datapelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d => $datapelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  
                                    <td><?php echo e($datapelanggan->id_pelanggan); ?></td>
                                    <td><?php echo e($datapelanggan->nama_pelanggan); ?></td>
                                    <td><?php echo e($datapelanggan->alamat); ?></td>
                                   
                                    
                                    
                                    <td class="text-center">
                                        <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('datapelanggans.destroy', $datapelanggan->id_pelanggan)); ?>" method="POST">
                                            <a href="<?php echo e(route('datapelanggans.edit', $datapelanggan->id_pelanggan)); ?>" class="btn btn-sm btn-primary">EDIT</a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger">HAPUS</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready( function () {
          $('#myTable').DataTable();
        } );
    </script>

</body>
</html><?php /**PATH C:\xampp\htdocs\DataObat\resources\views/index.blade.php ENDPATH**/ ?>